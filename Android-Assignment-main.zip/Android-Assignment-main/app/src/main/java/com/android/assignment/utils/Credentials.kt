package com.android.assignment.utils

object Credentials {
    const val BASE_URL = " https://my-json-server.typicode.com/easygautam/data/"

}