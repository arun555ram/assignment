This exercise is used to assess technical proficiency, coding-style, library-awareness and approach. It will be evaluated on both the code quality and the final product with equal weighting.
![img.png](img.png)
![img_1.png](img_1.png)

